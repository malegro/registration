
load('reg_lab_data');
